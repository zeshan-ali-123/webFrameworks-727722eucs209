package com.example.relation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelationApplicationTests {

	@Test
	void contextLoads() {
	}

}
